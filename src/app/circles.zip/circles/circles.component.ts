import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';


@Component({
  selector: 'circles-component',
  templateUrl: './circles.component.html',
  styleUrls: ['./circles.component.scss']
})

export class CirclesComponent implements AfterViewInit {
  @ViewChild('circles', {static: false}) circles: ElementRef;

  constructor() {

  }

  ngAfterViewInit(): void {
    var elementHeight = this.circles.nativeElement.offsetHeight; // Get the current height of the element

    // Update the CSS variable with the element's height
    this.circles.nativeElement.style.setProperty('--element-height', elementHeight + 'px');
  }

}
