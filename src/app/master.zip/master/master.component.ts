import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';

interface Etablissement {
  id: number;
  label: string;
}

@Component({
  selector: 'master-component',
  templateUrl: './master.component.html',
  styleUrls: ['./master.component.scss']
})


export class MasterComponent implements OnInit {

  public selectedEtablissement: Etablissement;
  public etablissementList: Etablissement[];

  constructor() {

  }

  ngOnInit(): void {
    console.log('slt');
    this.etablissementList = [
      {id: 22, label: 'Paris - Commune'},
      {id: 25, label: 'Villizy - Commune'},
      {id: 34, label: 'Nevers - Commune'},
      {id: 54, label: 'Clermont-Ferrand - Ville'},
      {id: 55, label: 'Clermont-Ferrand - Métropole'},
      {id: 60, label: 'Lyon - Ville'},
      {id: 61, label: 'Lyon - CHU'},
      {id: 62, label: 'Lyon - Métropole'},
    ]
  }

}
